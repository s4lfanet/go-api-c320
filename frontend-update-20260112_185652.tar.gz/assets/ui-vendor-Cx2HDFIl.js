import{r as c}from"./react-vendor-CZccnYFs.js";var i={exports:{}},s={};/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var _=c,a=Symbol.for("react.element"),m=Symbol.for("react.fragment"),y=Object.prototype.hasOwnProperty,x=_.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,R={key:!0,ref:!0,__self:!0,__source:!0};function l(r,e,u){var t,n={},o=null,f=null;u!==void 0&&(o=""+u),e.key!==void 0&&(o=""+e.key),e.ref!==void 0&&(f=e.ref);for(t in e)y.call(e,t)&&!R.hasOwnProperty(t)&&(n[t]=e[t]);if(r&&r.defaultProps)for(t in e=r.defaultProps,e)n[t]===void 0&&(n[t]=e[t]);return{$$typeof:a,type:r,key:o,ref:f,props:n,_owner:x.current}}s.Fragment=m;s.jsx=l;s.jsxs=l;i.exports=s;var v=i.exports;function p(r,e){if(typeof r=="function")return r(e);r!=null&&(r.current=e)}function E(...r){return e=>{let u=!1;const t=r.map(n=>{const o=p(n,e);return!u&&typeof o=="function"&&(u=!0),o});if(u)return()=>{for(let n=0;n<t.length;n++){const o=t[n];typeof o=="function"?o():p(r[n],null)}}}}export{E as c,v as j};
